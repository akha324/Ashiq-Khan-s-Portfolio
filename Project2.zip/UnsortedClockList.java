// The purpose of this class is to call another method called UnsortedClockList.
public class UnsortedClockList extends ClockList {
	    public UnsortedClockList (){
		       super();
        }

// The purpose of this function to add data to the clock arrays.
public void add (Clock data){
       append(data);
       }
}
